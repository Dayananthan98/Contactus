import React from "react";
import ReactDOM from "react-dom";
import { SocialMediaIconsReact } from "social-media-icons-react";

class NewComponent extends React.Component {
  render() {
    return (
      <div className="container">
        <div
          className="center wow fadeInDown animated"
          style={{ textAlign: "center" }}
        >
          <h2
            style={{
              backgroundColor: "rgb(38, 50, 56)",
              color: "white",
              fontFamily: "fontFamily",
            }}
          >
            Get in Touch with Us
            <div className="icons" style={{ padding: "10px" }}>
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="twitter"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(28,186,223,1)"
                iconSize="5"
                roundness="50%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="facebook"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(12,0,255,1)"
                iconSize="5"
                roundness="50%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="linkedin"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(132,125,222,1)"
                iconSize="5"
                roundness="0%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />{" "}
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="messenger"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(169,125,222,1)"
                iconSize="5"
                roundness="28%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="instagram"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(0,0,0,1)"
                iconSize="5"
                roundness="50%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />
              <SocialMediaIconsReact
                borderColor="rgba(0,0,0,0.25)"
                borderWidth="5"
                borderStyle="solid"
                icon="youtube"
                iconColor="rgba(255,255,255,1)"
                backgroundColor="rgba(242,0,0,1)"
                iconSize="5"
                roundness="0%"
                url="https://some-website.com/my-social-media-url"
                size="50"
              />
            </div>
          </h2>
        </div>

        <div
          class="col-sm-12 col-md-6"
          style={{
            backgroundColor: "rgb(38, 50, 56)",
            color: "white",
            fontFamily: "fontFamily",
          }}
        >
          <h2
            style={{
              textAlign: "center",
              color: "rgb(97, 218, 251)",
              fontSize: "xx-large",
            }}
          >
            Contact Information
          </h2>
          <div
            class="headings"
            style={{
              display: "flex",
              justifyContent: "space-between",
              padding: "60px",
            }}
          >
            <div
              className="left-side"
              style={{ fontSize: "x-large", paddingTop: "60px" }}
            >
              <ul class="contact_info">
                <li>
                  <i class="fa fa-location-arrow" aria-hidden="true"></i>{" "}
                  Address : 124 Rasavinthoddam Rd, Jaffna, Sri Lanka
                </li>
                <li>
                  <i class="fa fa-phone" aria-hidden="true"></i> Mobile :{" "}
                  <a
                    href="tel:+94 768 801 565"
                    style={{ color: "rgb(97, 218, 251)" }}
                  >
                    +94 768 801 565
                  </a>{" "}
                  (Dayananthan)
                </li>
                <li>
                  <i class="fa fa-phone" aria-hidden="true"></i> Mobile :{" "}
                  <a
                    href="tel:+94 762 305 644"
                    style={{ color: "rgb(97, 218, 251)" }}
                  >
                    +94 762 305 644
                  </a>{" "}
                  (AnithVithusan)
                </li>
                <li>
                  <i class="fa fa-phone" aria-hidden="true"></i> Office :{" "}
                  <a
                    href="tel:+94 %E2%80%8E33 494 2499"
                    style={{ color: "rgb(97, 218, 251)" }}
                  >
                    +94 333 340 669/ +94 33 494 2499
                  </a>
                </li>
                <li>
                  <i class="fa fa-envelope-o" aria-hidden="true"></i> Email :{" "}
                  <a
                    href="mailto:YarlMakket@gmail.com"
                    style={{ color: "rgb(97, 218, 251)" }}
                  >
                    YarlMakket@gmail.com
                  </a>
                </li>
              </ul>
            </div>
            <div className="right-side" style={{ paddingRight: "200px" }}>
              <div className="map" style={{ fontSize: "xx-large" }}>
                Locate us.
                <div style={{ width: "100%", marginTop: "50px" }}>
                  <iframe
                    width="150%"
                    height="300"
                    id="gmap_canvas"
                    src="https://maps.google.com/maps?q=uki%20jaffna&t=&z=13&ie=UTF8&iwloc=&output=embed"
                    frameborder="0"
                    scrolling="no"
                    marginheight="0"
                    marginwidth="0"
                  ></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div
          className="row contact-wrap"
          style={{ marginTop: "50px", fontFamily: "fontFamily" }}
        >
          <div
            className="center"
            style={{ paddingTop: "60px", textAlign: "center" }}
          >
            <h2 style={{ color: "blue", fontSize: "xxx-large" }}>
              Drop Your Message
            </h2>
          </div>
          <div
            className="status alert alert-success"
            style={{ display: "none" }}
          />
          <form
            id="main-contact-form"
            className="contact-form"
            name="contact-form"
            method="post"
            action="Success"
          >
            <div
              className="det"
              style={{
                display: "flex",
                justifyContent: "space-between",
                padding: "60px",
              }}
            >
              <div
                className="col-sm-6"
                style={{
                  fontSize: "x-large",
                  paddingLeft: "500px",
                }}
              >
                <div className="form-group">
                  <label>Name </label>
                  <div className="inputname">
                    <input
                      type="text"
                      name="name"
                      className="form-control"
                      required="required"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>Email </label>
                  <div className="inputemail">
                    <input
                      type="email"
                      name="email"
                      className="form-control"
                      required="required"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>PhoneNo.(Optional)</label>
                  <div className="inputphone">
                    <input
                      type="number"
                      name="phone"
                      className="form-control"
                    />
                  </div>
                </div>
              </div>
              <div
                className="col-sm-6"
                style={{
                  fontSize: "x-large",
                  paddingRight: "200px",
                  paddingBottom: "300px",
                }}
              >
                <div className="form-group">
                  <label>
                    <p style={{ margin: "0px" }}>Message </p>
                  </label>
                  <textarea
                    name="message"
                    id="message"
                    required
                    className="inform-control"
                    rows={8}
                    defaultValue={""}
                    style={{ paddingRight: "240px" }}
                  />
                </div>
                <div className="form-group">
                  <button
                    type="submit"
                    name="send_message"
                    className="btn-primary"
                    required="required"
                  >
                    Submit Message
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default NewComponent;
