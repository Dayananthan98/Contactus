import React from 'react';
import Skills from './Skills';




const Employee = (props) => {
     return (<div>  
      <h1>Name: {props.name}</h1>
      <h1>Id  : {props.id} </h1>
      <Skills myskill='Polymath'></Skills>
      
      </div>
     )
    
}

 
// class Employee extends React.Component {
//     render() {  
//       return (<div>  
//             <h1>Name: {this.props.name}</h1>
//             <h1>Id  : {this.props.id} </h1>
//               </div>
//       )
//     }
// }










  



export default Employee;
