import React from 'react';

const Fuldetails = (props) => {
    return (
        <h1 style={{color:"brown"}}>Location : {props.mylocation} </h1>
    )
}



export default Fuldetails;

