import React from 'react';
import Fuldetails from './Fulldetails';

const Skills = (props) => {
    return (
        <div>
        <h1 style={{color:"blue"}}>My skill : {props.myskill} </h1>
        <Fuldetails mylocation='Singapore'></Fuldetails>
        </div>
    )
} 







export default Skills;

