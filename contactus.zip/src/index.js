import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import Employee from "./Employee";
import Form from "./Form";
import Contactus from "./ContactUs";
import Adduser from "./Adduser";
import Addproduct from "./Addproduct";
import Payments from "./Components/Payments";

//ReactDOM.render(<App />, document.getElementById("root"));
//ReactDOM.render(<Form />, document.getElementById("root"));

ReactDOM.render(<Contactus />, document.getElementById("root"));
//ReactDOM.render(<Adduser />, document.getElementById("root"));
//ReactDOM.render(<Addproduct />, document.getElementById("root"));
//ReactDOM.render(<Payments />, document.getElementById("root"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
